fixture package for T4 install test
